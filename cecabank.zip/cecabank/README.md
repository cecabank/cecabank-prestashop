# Cecabank Módulo Prestashop


# Descripción

El módulo de Cecabank para Prestashop permite realizar cobros a tus clientes utilizando el TPV de Cecabank.

# Instalación manual

El método de instalación manual se refiere a descargar nuestro plugin y subirlo a través del Dashboard de Prestashop vía ftp a su servidor. Prestashop tiene un artículo con [con las instrucciones de como hacerlo aquí](https://addons.prestashop.com/en/content/13-installing-modules).

# Actualización

Automáticamente se realizarán las actualizaciones y funcionarán de manera normal; de todas formas, siempre asegúrese de realizar un backup a su sitio por si acaso.

# Uso

Para utilizar el plugin usted necesita tener acceso a un TPV de Cecabank para poder obtener las credenciales.

